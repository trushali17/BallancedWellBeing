<?php

/* Create the Gallery Item Custom Post Type */
function medical_pro_create_gallery_post_type() 
{
	$labels = array(
		'name' => __( 'Gallery Items','medical-pro'),
		'singular_name' => __( 'Gallery Item','medical-pro' ),
		'add_new' => __('Add New','medical-pro'),
		'add_new_item' => __('Add New Gallery Item','medical-pro'),
		'edit_item' => __('Edit Gallery Item','medical-pro'),
		'new_item' => __('New Gallery Item','medical-pro'),
		'view_item' => __('View Gallery Item','medical-pro'),
		'search_items' => __('Search Gallery Items','medical-pro'),
		'not_found' =>  __('No Gallery Item found','medical-pro'),
		'not_found_in_trash' => __('No Gallery Item found in Trash','medical-pro'), 
		'parent_item_colon' => ''
	  );
	  
	  $args = array(
		 'labels'        => $labels, //labels - An array of labels for this post type. By default, post labels are used for non-hierarchical post types and page labels for hierarchical ones.
            'public'        => true, //Controls how the type is visible to authors (show_in_nav_menus, show_ui) and readers
            'hierarchical'  => false, //Whether the post type is hierarchical (e.g. page). Allows Parent to be specified. The 'supports' parameter should contain 'page-attributes' to show the parent select box on the editor page.
            'menu_position' => 5, //The position in the menu order the post type should appear. show_in_menu must be true.
            'supports'      => array('title','editor','thumbnail'), // Possible attributes (title, editor, author, thumbnail, excerpt, trackbacks, custom-fields, comments, revisions, page-attributes, post-formats)
			'rewrite' => array( 'slug' => __('gallery-item', 'medical-pro') ),
			'exclude_from_search' => true, //Whether to exclude posts with this post type from front end search results.
            'publicly_queryable' => true //Whether queries can be performed on the front end as part of parse_request().
	  ); 
	  
	  register_post_type('gallery-item',$args);
}
add_action( 'init', 'medical_pro_create_gallery_post_type' );



/* Create Gallery Item Type Taxonomy */
function create_gallery_item_type_taxonomy(){
    $labels = array(
        'name' => __( 'Gallery Item Types', 'medical-pro' ),
        'singular_name' => __( 'Gallery Item Type', 'medical-pro' ),
        'search_items' =>  __( 'Search Gallery Item Types', 'medical-pro' ),
        'popular_items' => __( 'Popular Gallery Item Types', 'medical-pro' ),
        'all_items' => __( 'All Gallery Item Types', 'medical-pro' ),
        'parent_item' => __( 'Parent Gallery Item Type', 'medical-pro' ),
        'parent_item_colon' => __( 'Parent Gallery Item Type:', 'medical-pro' ),
        'edit_item' => __( 'Edit Gallery Item Type', 'medical-pro' ), 
        'update_item' => __( 'Update Gallery Item Type', 'medical-pro' ),
        'add_new_item' => __( 'Add New Gallery Item Type', 'medical-pro' ),
        'new_item_name' => __( 'New Gallery Item Type Name', 'medical-pro' ),
        'separate_items_with_commas' => __( 'Separate Gallery Item Types with commas', 'medical-pro' ),
        'add_or_remove_items' => __( 'Add or Remove Gallery Item Types', 'medical-pro' ),
        'choose_from_most_used' => __( 'Choose from the most used Gallery Item Types', 'medical-pro' ),
        'menu_name' => __( 'Gallery Item Types', 'medical-pro' )
    );
    
	register_taxonomy(
	    'gallery-type', 
	    array( 'gallery-item' ), 
	    array(
	        'hierarchical' => true, 
	        'labels' => $labels,
	        'show_ui' => true,
	        'query_var' => true,
	        'rewrite' => array('slug' => __('gallery-type', 'medical-pro'))
	    )
	); 
}

add_action( 'init', 'create_gallery_item_type_taxonomy', 0 );


/* Add Custom Columns */
function gallery_edit_columns($columns){  

        $columns = array(  
            "cb" => "<input type=\"checkbox\" />",  
            "title" => __('Gallery Item Title','medical-pro'),
			"gallery-thumb" => __('Thumbnail','medical-pro'),
            "type" => __('Gallery Item Type','medical-pro'),
			"date" => __('Publish Time', 'medical-pro')
        );
  
        return $columns;  
}  
  
function gallery_custom_columns($column){  
        global $post;  
        switch ($column)  
        {    
            case 'gallery-thumb': 			 
				if(has_post_thumbnail($post->ID)) 
				{
					?>
					<a href="<?php the_permalink(); ?>" target="_blank">
						<?php the_post_thumbnail( 'gallery-post-single-thumb' ); ?>
					</a>
					<?php
				}
				else
				{
					_e('No Thumbnail','medical-pro');
				}
                break;
			
			case 'type':  
                echo get_the_term_list($post->ID, 'gallery-type', '', ', ','');  
                break;
        }  
} 
add_filter("manage_edit-gallery-item_columns", "gallery_edit_columns");  
add_action("manage_posts_custom_column",  "gallery_custom_columns");

?>