<div class="field">
	<label class="field-label"><?php esc_html_e("Enter your email address to reset your password:","booked"); ?></label>
</div>
	
<div class="field">
	<input value="" placeholder="<?php esc_html_e('Email Address','booked'); ?> ..." class="textfield large" id="username" name="username" type="text" >
</div>